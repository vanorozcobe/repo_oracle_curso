// programacion  del JS del challenger amigo secreto

//Declaracion de variables 
let amigo = [];


//Creacion de funciones
//Punto 1 del challenger , recibir el nombre en un campo de texto
function agregarAmigo(){
    let inpAmigo = document.getElementById("amigo");
    let nombreAmigo = inpAmigo.value;
    //console.log(nombreAmigo);

    //Validacion para no permitir ingreso de campos vacios a la lista
    // indicar al usuario que debe ingresar un nombre punto 2 indicaciones de challenger

    if(!nombreAmigo){
        alert("Debe ingresar un nombre, no se permiten datos vacios");
        return;
    }

    //Punto 1 del challenger , agregar los nombres a un array
    amigo.push(nombreAmigo);
    limpiarCaja();
    mostrarAmigos();
    //console.log(amigo);
}

// Punto 3 del challenger mostrar la lista de amigos en pantalla
function mostrarAmigos(){
    let listaAmigos = document.getElementById("listaAmigos");
    listaAmigos.innerHTML =""; // limpia el arreglo para que no se repitan los nombres de los amigos
    
    for(let a =0; a < amigo.length; a++){
        let item = document.createElement("li");
        item.textContent = amigo[a];
        listaAmigos.appendChild(item);
    }
}

// Punto 4 del challenger funcion para sortear amigos
function sortearAmigo(){
    if(amigo.length === 0){
        alert("No hay amigos registrados para realizar el sorteo");
        return;
    }
    let amigoGanador = amigo[Math.floor(Math.random() * amigo.length)];
    let = resultado = document.getElementById("resultado");
    resultado.innerHTML = `El amigo ganador del sorteo es: ${amigoGanador}`;
    let limpiarLista = document.getElementById("listaAmigos");
    limpiarLista.innerHTML = "";
}
// funcion para limpiar el boton
function limpiarCaja() {
    document.querySelector("#amigo").value = '';
}






